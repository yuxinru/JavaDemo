package com.pinnet.zookeeper.service;

public interface ITestService {

    String test(String name);
}
