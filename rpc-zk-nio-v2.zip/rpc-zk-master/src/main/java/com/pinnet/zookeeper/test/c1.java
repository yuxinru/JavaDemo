package com.pinnet.zookeeper.test;

import com.pinnet.zookeeper.client.Client;
import com.pinnet.zookeeper.client.nioClient;

import java.util.Scanner;

public class c1 {
    public static void main(String[] args) throws Exception {
        nioClient.start();
        while(true){
            Thread.sleep(3000);
            nioClient.sendMsg("c1");
        }
        //while(nioClient.sendMsg(new Scanner(System.in).nextLine()));
    }
}
