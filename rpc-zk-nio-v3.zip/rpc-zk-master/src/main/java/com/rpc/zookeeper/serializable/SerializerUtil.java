package com.rpc.zookeeper.serializable;

public interface SerializerUtil {
    byte[] serialize(Object obj);
     <T> T deserialize(byte[] bytes);
}
