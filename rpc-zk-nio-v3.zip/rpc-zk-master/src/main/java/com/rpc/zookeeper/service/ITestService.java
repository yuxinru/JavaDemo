package com.rpc.zookeeper.service;

public interface ITestService {

    String test(String name);
}
