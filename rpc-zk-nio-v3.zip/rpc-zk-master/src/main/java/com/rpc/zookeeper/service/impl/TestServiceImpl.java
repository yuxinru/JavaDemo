package com.rpc.zookeeper.service.impl;

import com.rpc.zookeeper.service.ITestService;

public class TestServiceImpl implements ITestService{

    public String test(String name) {
        System.out.println(name);
        return "return(" + name+")";
    }
}
