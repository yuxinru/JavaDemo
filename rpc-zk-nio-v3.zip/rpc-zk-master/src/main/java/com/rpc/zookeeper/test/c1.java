package com.rpc.zookeeper.test;

import com.rpc.zookeeper.client.nioClient;

public class c1 {
    public static void main(String[] args) throws Exception {
        nioClient.start();
        while(true){
            Thread.sleep(3000);
            nioClient.sendMsg("c1");
        }
        //while(nioClient.sendMsg(new Scanner(System.in).nextLine()));
    }
}
