package com.rpc.zookeeper.test;

import com.rpc.zookeeper.client.nioClient;

public class c2 {
    public static void main(String[] args) throws Exception {
        nioClient.start();
        while(true){
            Thread.sleep(3000);
            nioClient.sendMsg("c2");
        }
        //while(nioClient.sendMsg(new Scanner(System.in).nextLine()));
    }
}
